BOSTON UNIVERSITY EDF
eVOLVER System

EV-ADC Rev B

4 layers
0.063 final thickness FR-4
1 oz copper
soldermask both sides (green)
silkscreen legend top only (white)

Contact:  Chris Lawlor / 617-353-4117 / cjlawlor@bu.edu

ADC-F.Cu.gbr           Layer 1 (positive)
ADC-In1.Cu.gbr         Layer 2 (positive)
ADC-In2.Cu.gbr         Layer 3 (positive)
ADC-B.Cu.gbr           Layer 4 (positive)
ADC-F.Mask.gbr         Front soldermask
ADC-F.Paste.gbr        Front solder paste
ADC-F.SilkS.gbr        Front silkscreen
ADC-B.Mask.gbr         Back soldermask
ADC.drl                NC Drill
ADC-Dwgs.User.gbr      Fab drawing
ADC-Edge.Cuts.gbr      Board outline
ADC-all.pos            Placement positions

